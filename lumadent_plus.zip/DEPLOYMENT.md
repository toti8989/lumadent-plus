Deploy quickly:
- Frontend can be deployed to Vercel (set VITE_API_URL to your backend URL)
- Backend can be deployed to Render (node service)
- Or run both with docker-compose on a VPS.

If you want, provide Render/Vercel access and I can guide step-by-step.
