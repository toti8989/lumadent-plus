import React, { useEffect, useState } from 'react';
import API from '../api';
export default function AppointmentList({ patients, token }){
  const [appts, setAppts] = useState([]);
  const [form, setForm] = useState({ patient_id:'', date:'', time:'', duration:30, type:'Приём', notes:''});
  const fetch = async () => { const r = await API.get('/appointments', { headers:{ Authorization:`Bearer ${token}` } }); setAppts(r.data); }
  useEffect(()=>{ fetch(); }, []);
  const save = async () => { await API.post('/appointments', form, { headers:{ Authorization:`Bearer ${token}` } }); fetch(); }
  return (
    <div>
      <h2>Приёмы</h2>
      <div>
        <select value={form.patient_id} onChange={e=>setForm({...form, patient_id: e.target.value})}>
          <option value="">-- Пациент --</option>
          {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        <input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})} />
        <input type="time" value={form.time} onChange={e=>setForm({...form,time:e.target.value})} />
        <button onClick={save}>Добавить</button>
      </div>
      <ul>
        {appts.map(a => (<li key={a.id}>{a.date} {a.time} — {a.type} (patient {a.patient_id})</li>))}
      </ul>
    </div>
  )
}
