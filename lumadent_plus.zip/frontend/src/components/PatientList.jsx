import React from 'react';
import API from '../api';
export default function PatientList({ patients, refresh, token }){
  const del = async (id) => { await API.delete(`/patients/${id}`, { headers:{ Authorization:`Bearer ${token}` } }); refresh(); }
  return (
    <div>
      <h2>Пациенты</h2>
      <ul>
        {patients.map(p => (
          <li key={p.id}>{p.name} — {p.phone}
            <button style={{marginLeft:8}} onClick={() => del(p.id)}>Удалить</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
