import React, { useState } from 'react';
import axios from 'axios';
export default function Login({ onLogin }) {
  const [form, setForm] = useState({ username:'admin', password:'1234' });
  const [err, setErr] = useState('');
  const submit = async () => {
    try {
      const r = await axios.post((import.meta.env.VITE_API_URL || 'http://localhost:4000') + '/api/login', form);
      onLogin(r.data.token);
    } catch (e) {
      setErr('Неверный логин или пароль');
    }
  }
  return (
    <div className="login">
      <h2>Lumadent+ — Вход</h2>
      <input value={form.username} onChange={e=>setForm({...form,username:e.target.value})} />
      <input type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} />
      <button onClick={submit}>Войти</button>
      {err && <div style={{color:'red'}}>{err}</div>}
      <p>Демо: admin / 1234</p>
    </div>
  )
}
