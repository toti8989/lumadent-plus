import React, { useState } from 'react';
import API from '../api';
export default function PatientForm({ onSaved, token }){
  const [form, setForm] = useState({ name:'', phone:'', email:'', birthdate:'', notes:'' });
  const save = async () => {
    await API.post('/patients', form, { headers:{ Authorization:`Bearer ${token}` } });
    setForm({ name:'', phone:'', email:'', birthdate:'', notes:'' });
    onSaved();
  }
  return (
    <div>
      <h3>Новый пациент</h3>
      <input placeholder="Имя" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
      <input placeholder="Телефон" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} />
      <input placeholder="Email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} />
      <input placeholder="Дата рождения" value={form.birthdate} onChange={e=>setForm({...form,birthdate:e.target.value})} />
      <textarea placeholder="Заметки" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} />
      <button onClick={save}>Сохранить</button>
    </div>
  )
}
