import React, { useEffect, useState } from 'react';
import API from './api';
import PatientList from './components/PatientList';
import PatientForm from './components/PatientForm';
import AppointmentList from './components/AppointmentList';
import Login from './components/Login';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('lumadent_token') || '');
  const [patients, setPatients] = useState([]);

  const fetchPatients = async () => {
    try {
      const res = await API.get('/patients', { headers: { Authorization: `Bearer ${token}` } });
      setPatients(res.data);
    } catch (e) {
      console.error(e);
    }
  }

  useEffect(() => {
    if (token) fetchPatients();
  }, [token]);

  if (!token) {
    return <Login onLogin={(t)=>{ setToken(t); localStorage.setItem('lumadent_token', t); }} />;
  }

  return (
    <div className="app">
      <h1>Lumadent+</h1>
      <button onClick={()=>{ localStorage.removeItem('lumadent_token'); setToken(''); }}>Выход</button>
      <div className="columns">
        <div className="left">
          <PatientForm onSaved={fetchPatients} token={token} />
          <PatientList patients={patients} refresh={fetchPatients} token={token} />
        </div>
        <div className="right">
          <AppointmentList patients={patients} token={token} />
        </div>
      </div>
    </div>
  )
}
