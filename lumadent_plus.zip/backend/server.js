require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const { db, init } = require('./db');

init();

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || '1234';
const TOKEN = process.env.AUTH_TOKEN || 'lumadent-secret-token';

// Simple login endpoint
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    return res.json({ token: TOKEN, name: 'Admin' });
  }
  return res.status(401).json({ error: 'Invalid credentials' });
});

// Auth middleware
function auth(req, res, next) {
  const h = req.headers.authorization || '';
  if (h === `Bearer ${TOKEN}`) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

// Protected API routes
app.get('/api/patients', auth, (req, res) => {
  db.all('SELECT * FROM patients', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/patients', auth, (req, res) => {
  const { name, phone, email, birthdate, notes } = req.body;
  db.run(
    'INSERT INTO patients (name, phone, email, birthdate, notes) VALUES (?, ?, ?, ?, ?)',
    [name, phone, email, birthdate, notes],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

app.delete('/api/patients/:id', auth, (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM patients WHERE id=?', [id], function (err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ deleted: this.changes });
  });
});

// Appointments
app.get('/api/appointments', auth, (req, res) => {
  db.all('SELECT * FROM appointments', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/appointments', auth, (req, res) => {
  const { patient_id, date, time, duration, type, notes } = req.body;
  db.run(
    'INSERT INTO appointments (patient_id, date, time, duration, type, notes) VALUES (?, ?, ?, ?, ?, ?)',
    [patient_id, date, time, duration, type, notes],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log('Lumadent+ backend running on', PORT));
