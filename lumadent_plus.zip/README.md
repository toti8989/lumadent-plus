Lumadent+ — demo web app (patients, appointments, calendar)

Default credentials:
  username: admin
  password: 1234

Local Docker run:
  docker compose up --build
Open http://localhost

To deploy to Render/Vercel, see DEPLOYMENT.md
